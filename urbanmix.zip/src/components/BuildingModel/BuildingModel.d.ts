import React from 'react';

const BuildingModel: React.FC;
export default BuildingModel;
